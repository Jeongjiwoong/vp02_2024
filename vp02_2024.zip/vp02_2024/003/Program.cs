﻿using System;

namespace _003
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double w, h;

            Console.WriteLine("체중(kg) :");
            w = double.Parse(Console.ReadLine());

            Console.WriteLine("키(cm) :");
            h = double.Parse(Console.ReadLine());

            double bmi = w / ((h/100) * (h/100));
            Console.WriteLine("BMI =" + bmi);
        }
    }
}