﻿namespace _014_university_score
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txt1 = new TextBox();
            txt2 = new TextBox();
            txt3 = new TextBox();
            txt4 = new TextBox();
            txt5 = new TextBox();
            txt6 = new TextBox();
            txt7 = new TextBox();
            txt8 = new TextBox();
            crd1 = new ComboBox();
            crd2 = new ComboBox();
            crd3 = new ComboBox();
            crd4 = new ComboBox();
            crd5 = new ComboBox();
            crd6 = new ComboBox();
            crd7 = new ComboBox();
            crd8 = new ComboBox();
            grd1 = new ComboBox();
            grd2 = new ComboBox();
            grd3 = new ComboBox();
            grd4 = new ComboBox();
            grd5 = new ComboBox();
            grd6 = new ComboBox();
            grd7 = new ComboBox();
            grd8 = new ComboBox();
            txtGrade = new TextBox();
            btm = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(73, 44);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 0;
            label1.Text = "과목";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(181, 44);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 1;
            label2.Text = "학점";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(275, 44);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 2;
            label3.Text = "성적";
            // 
            // txt1
            // 
            txt1.Location = new Point(27, 75);
            txt1.Name = "txt1";
            txt1.Size = new Size(124, 23);
            txt1.TabIndex = 3;
            // 
            // txt2
            // 
            txt2.Location = new Point(27, 104);
            txt2.Name = "txt2";
            txt2.Size = new Size(124, 23);
            txt2.TabIndex = 4;
            // 
            // txt3
            // 
            txt3.Location = new Point(27, 133);
            txt3.Name = "txt3";
            txt3.Size = new Size(124, 23);
            txt3.TabIndex = 5;
            // 
            // txt4
            // 
            txt4.Location = new Point(27, 162);
            txt4.Name = "txt4";
            txt4.Size = new Size(124, 23);
            txt4.TabIndex = 6;
            // 
            // txt5
            // 
            txt5.Location = new Point(27, 191);
            txt5.Name = "txt5";
            txt5.Size = new Size(124, 23);
            txt5.TabIndex = 7;
            // 
            // txt6
            // 
            txt6.Location = new Point(27, 220);
            txt6.Name = "txt6";
            txt6.Size = new Size(124, 23);
            txt6.TabIndex = 8;
            // 
            // txt7
            // 
            txt7.Location = new Point(27, 249);
            txt7.Name = "txt7";
            txt7.Size = new Size(124, 23);
            txt7.TabIndex = 9;
            // 
            // txt8
            // 
            txt8.Location = new Point(27, 278);
            txt8.Name = "txt8";
            txt8.Size = new Size(124, 23);
            txt8.TabIndex = 10;
            // 
            // crd1
            // 
            crd1.FormattingEnabled = true;
            crd1.Location = new Point(168, 75);
            crd1.Name = "crd1";
            crd1.Size = new Size(58, 23);
            crd1.TabIndex = 11;
            // 
            // crd2
            // 
            crd2.FormattingEnabled = true;
            crd2.Location = new Point(168, 104);
            crd2.Name = "crd2";
            crd2.Size = new Size(58, 23);
            crd2.TabIndex = 12;
            // 
            // crd3
            // 
            crd3.FormattingEnabled = true;
            crd3.Location = new Point(168, 133);
            crd3.Name = "crd3";
            crd3.Size = new Size(58, 23);
            crd3.TabIndex = 13;
            // 
            // crd4
            // 
            crd4.FormattingEnabled = true;
            crd4.Location = new Point(168, 162);
            crd4.Name = "crd4";
            crd4.Size = new Size(58, 23);
            crd4.TabIndex = 14;
            // 
            // crd5
            // 
            crd5.FormattingEnabled = true;
            crd5.Location = new Point(168, 191);
            crd5.Name = "crd5";
            crd5.Size = new Size(58, 23);
            crd5.TabIndex = 15;
            // 
            // crd6
            // 
            crd6.FormattingEnabled = true;
            crd6.Location = new Point(168, 220);
            crd6.Name = "crd6";
            crd6.Size = new Size(58, 23);
            crd6.TabIndex = 16;
            // 
            // crd7
            // 
            crd7.FormattingEnabled = true;
            crd7.Location = new Point(168, 249);
            crd7.Name = "crd7";
            crd7.Size = new Size(58, 23);
            crd7.TabIndex = 17;
            // 
            // crd8
            // 
            crd8.FormattingEnabled = true;
            crd8.Location = new Point(168, 278);
            crd8.Name = "crd8";
            crd8.Size = new Size(58, 23);
            crd8.TabIndex = 18;
            // 
            // grd1
            // 
            grd1.FormattingEnabled = true;
            grd1.Location = new Point(264, 75);
            grd1.Name = "grd1";
            grd1.Size = new Size(58, 23);
            grd1.TabIndex = 19;
            // 
            // grd2
            // 
            grd2.FormattingEnabled = true;
            grd2.Location = new Point(264, 104);
            grd2.Name = "grd2";
            grd2.Size = new Size(58, 23);
            grd2.TabIndex = 20;
            // 
            // grd3
            // 
            grd3.FormattingEnabled = true;
            grd3.Location = new Point(264, 133);
            grd3.Name = "grd3";
            grd3.Size = new Size(58, 23);
            grd3.TabIndex = 21;
            // 
            // grd4
            // 
            grd4.FormattingEnabled = true;
            grd4.Location = new Point(264, 162);
            grd4.Name = "grd4";
            grd4.Size = new Size(58, 23);
            grd4.TabIndex = 22;
            // 
            // grd5
            // 
            grd5.FormattingEnabled = true;
            grd5.Location = new Point(264, 191);
            grd5.Name = "grd5";
            grd5.Size = new Size(58, 23);
            grd5.TabIndex = 23;
            // 
            // grd6
            // 
            grd6.FormattingEnabled = true;
            grd6.Location = new Point(264, 220);
            grd6.Name = "grd6";
            grd6.Size = new Size(58, 23);
            grd6.TabIndex = 24;
            // 
            // grd7
            // 
            grd7.FormattingEnabled = true;
            grd7.Location = new Point(264, 249);
            grd7.Name = "grd7";
            grd7.Size = new Size(58, 23);
            grd7.TabIndex = 25;
            // 
            // grd8
            // 
            grd8.FormattingEnabled = true;
            grd8.Location = new Point(264, 278);
            grd8.Name = "grd8";
            grd8.Size = new Size(58, 23);
            grd8.TabIndex = 26;
            // 
            // txtGrade
            // 
            txtGrade.Location = new Point(264, 326);
            txtGrade.Name = "txtGrade";
            txtGrade.Size = new Size(58, 23);
            txtGrade.TabIndex = 27;
            // 
            // btm
            // 
            btm.Location = new Point(156, 326);
            btm.Name = "btm";
            btm.Size = new Size(70, 23);
            btm.TabIndex = 28;
            btm.Text = "계산하기";
            btm.UseVisualStyleBackColor = true;
            btm.Click += btm_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btm);
            Controls.Add(txtGrade);
            Controls.Add(grd8);
            Controls.Add(grd7);
            Controls.Add(grd6);
            Controls.Add(grd5);
            Controls.Add(grd4);
            Controls.Add(grd3);
            Controls.Add(grd2);
            Controls.Add(grd1);
            Controls.Add(crd8);
            Controls.Add(crd7);
            Controls.Add(crd6);
            Controls.Add(crd5);
            Controls.Add(crd4);
            Controls.Add(crd3);
            Controls.Add(crd2);
            Controls.Add(crd1);
            Controls.Add(txt8);
            Controls.Add(txt7);
            Controls.Add(txt6);
            Controls.Add(txt5);
            Controls.Add(txt4);
            Controls.Add(txt3);
            Controls.Add(txt2);
            Controls.Add(txt1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "학점계산기";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txt1;
        private TextBox txt2;
        private TextBox txt3;
        private TextBox txt4;
        private TextBox txt5;
        private TextBox txt6;
        private TextBox txt7;
        private TextBox txt8;
        private ComboBox crd1;
        private ComboBox crd2;
        private ComboBox crd3;
        private ComboBox crd4;
        private ComboBox crd5;
        private ComboBox crd6;
        private ComboBox crd7;
        private ComboBox crd8;
        private ComboBox grd1;
        private ComboBox grd2;
        private ComboBox grd3;
        private ComboBox grd4;
        private ComboBox grd5;
        private ComboBox grd6;
        private ComboBox grd7;
        private ComboBox grd8;
        private TextBox txtGrade;
        private Button btm;
    }
}