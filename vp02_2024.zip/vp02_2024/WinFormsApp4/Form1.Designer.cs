﻿namespace WinFormsApp4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btm = new Button();
            lbl1 = new Label();
            txtName = new TextBox();
            lbl2 = new Label();
            SuspendLayout();
            // 
            // btm
            // 
            btm.Location = new Point(307, 59);
            btm.Name = "btm";
            btm.Size = new Size(75, 23);
            btm.TabIndex = 0;
            btm.Text = "button1";
            btm.UseVisualStyleBackColor = true;
            btm.Click += btm_Click;
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Location = new Point(101, 63);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(38, 15);
            lbl1.TabIndex = 1;
            lbl1.Text = "이름 :";
            // 
            // txtName
            // 
            txtName.Location = new Point(173, 59);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 2;
            // 
            // lbl2
            // 
            lbl2.AutoSize = true;
            lbl2.Location = new Point(206, 115);
            lbl2.Name = "lbl2";
            lbl2.Size = new Size(0, 15);
            lbl2.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(464, 214);
            Controls.Add(lbl2);
            Controls.Add(txtName);
            Controls.Add(lbl1);
            Controls.Add(btm);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btm;
        private Label lbl1;
        private TextBox txtName;
        private Label lbl2;
    }
}