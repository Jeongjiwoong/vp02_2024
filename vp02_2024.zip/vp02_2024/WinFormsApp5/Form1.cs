namespace WinFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btm_Click(object sender, EventArgs e)
        {
            string checkStates = "";
            CheckBox[] cBox = { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5 };

            foreach (var item in cBox)
            {
                checkStates += string.Format("{0} : {1}\n", item.Text, item.Checked);
            }
            MessageBox.Show(checkStates, "�����ϴ� ������?");
            string summary = "�����ϴ� ������ :";
            foreach (var item in cBox)
            {
                if (item.Checked == true)
                {
                    summary += item.Text + " ";
                }
            }
            MessageBox.Show(summary, "Summary");
        }
    }
}
