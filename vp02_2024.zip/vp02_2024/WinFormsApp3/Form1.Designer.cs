﻿namespace WinFormsApp3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            lblBMI = new Label();
            lblresult = new Label();
            pictureBox1 = new PictureBox();
            txth = new TextBox();
            txtw = new TextBox();
            bmi = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 50);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 0;
            label1.Text = "키(cm)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 87);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 1;
            label2.Text = "체중(kg)";
            // 
            // lblBMI
            // 
            lblBMI.AutoSize = true;
            lblBMI.Location = new Point(32, 183);
            lblBMI.Name = "lblBMI";
            lblBMI.Size = new Size(39, 15);
            lblBMI.TabIndex = 2;
            lblBMI.Text = "label3";
            // 
            // lblresult
            // 
            lblresult.AutoSize = true;
            lblresult.Location = new Point(32, 224);
            lblresult.Name = "lblresult";
            lblresult.Size = new Size(39, 15);
            lblresult.TabIndex = 3;
            lblresult.Text = "label4";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(207, 183);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(82, 56);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // txth
            // 
            txth.Location = new Point(125, 46);
            txth.Name = "txth";
            txth.Size = new Size(100, 23);
            txth.TabIndex = 5;
            // 
            // txtw
            // 
            txtw.Location = new Point(125, 87);
            txtw.Name = "txtw";
            txtw.Size = new Size(100, 23);
            txtw.TabIndex = 6;
            // 
            // bmi
            // 
            bmi.Location = new Point(137, 144);
            bmi.Name = "bmi";
            bmi.Size = new Size(75, 23);
            bmi.TabIndex = 7;
            bmi.Text = "BMI";
            bmi.UseVisualStyleBackColor = true;
            bmi.Click += bmi_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(318, 333);
            Controls.Add(bmi);
            Controls.Add(txtw);
            Controls.Add(txth);
            Controls.Add(pictureBox1);
            Controls.Add(lblresult);
            Controls.Add(lblBMI);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label lblBMI;
        private Label lblresult;
        private PictureBox pictureBox1;
        private TextBox txth;
        private TextBox txtw;
        private Button bmi;
    }
}