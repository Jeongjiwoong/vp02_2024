namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bmi_Click(object sender, EventArgs e)
        {
            double w = double.Parse(txtw.Text);
            double h = double.Parse(txth.Text) / 100;

            double bmi = w / (h * h);

            lblBMI.Text = string.Format("MBI = {0:F2}", bmi);
            if (bmi < 20)
            {
                lblresult.Text = "��ü���Դϴ�.";
                pictureBox1.BackColor = Color.Blue;
            }
            else if (bmi < 25)
            {
                lblresult.Text = "����ü���Դϴ�.";
                pictureBox1.BackColor = Color.Green;
            }
            else if (bmi < 30)
            {
                lblresult.Text = "�浵���Դϴ�.";
                pictureBox1.BackColor = Color.Yellow;
            }
            else if (bmi < 40)
            {
                lblresult.Text = " ���Դϴ�.";
                pictureBox1.BackColor = Color.Orange;
            }
            else
            {
                lblresult.Text = " �������Դϴ�.";
                pictureBox1.BackColor = Color.Red;
            }
        }
    }
}