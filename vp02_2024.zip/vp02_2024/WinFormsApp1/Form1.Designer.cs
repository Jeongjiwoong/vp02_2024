﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txth = new TextBox();
            btmBMI = new Button();
            txtw = new TextBox();
            label2 = new Label();
            BMI = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(61, 66);
            label1.Name = "label1";
            label1.Size = new Size(19, 15);
            label1.TabIndex = 0;
            label1.Text = "키";
            // 
            // txth
            // 
            txth.Location = new Point(122, 63);
            txth.Name = "txth";
            txth.Size = new Size(100, 23);
            txth.TabIndex = 1;
            // 
            // btmBMI
            // 
            btmBMI.Location = new Point(133, 194);
            btmBMI.Name = "btmBMI";
            btmBMI.Size = new Size(75, 23);
            btmBMI.TabIndex = 2;
            btmBMI.Text = "BMI";
            btmBMI.UseVisualStyleBackColor = true;
            btmBMI.Click += BMI_Click;
            // 
            // txtw
            // 
            txtw.Location = new Point(122, 126);
            txtw.Name = "txtw";
            txtw.Size = new Size(100, 23);
            txtw.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(52, 134);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 4;
            label2.Text = "체중";
            // 
            // BMI
            // 
            BMI.AutoSize = true;
            BMI.Location = new Point(55, 247);
            BMI.Name = "BMI";
            BMI.Size = new Size(35, 15);
            BMI.TabIndex = 5;
            BMI.Text = "BMI :";
            BMI.Click += label3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(317, 331);
            Controls.Add(BMI);
            Controls.Add(label2);
            Controls.Add(txtw);
            Controls.Add(btmBMI);
            Controls.Add(txth);
            Controls.Add(label1);
            Name = "Form1";
            Text = "BMI 계산기";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox ㅅㅌㅅ;
        private Button btmBMI;
        private TextBox textBox2;
        private Label label2;
        private TextBox txth;
        private TextBox txtw;
        private Label BMI;
    }
}