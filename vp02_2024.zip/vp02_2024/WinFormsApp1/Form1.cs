namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BMI_Click(object sender, EventArgs e)
        {
            double h = double.Parse(txth.Text)/100;
            double w = double.Parse(txtw.Text);
            double bmi = w / (h * h);
            BMI.Text = "BMI = " + bmi;
            
        }
    }
}