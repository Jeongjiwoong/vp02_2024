﻿namespace _013_1_convert
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            groupBox2 = new GroupBox();
            txtavg = new TextBox();
            txtsum = new TextBox();
            avg = new Label();
            sum = new Label();
            groupBox1 = new GroupBox();
            textBox3 = new TextBox();
            txtmath = new TextBox();
            txtko = new TextBox();
            txteng = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(501, 205);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "계산";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtavg);
            groupBox2.Controls.Add(txtsum);
            groupBox2.Controls.Add(avg);
            groupBox2.Controls.Add(sum);
            groupBox2.Location = new Point(409, 75);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(200, 100);
            groupBox2.TabIndex = 4;
            groupBox2.TabStop = false;
            groupBox2.Text = "결과";
            // 
            // txtavg
            // 
            txtavg.Location = new Point(92, 64);
            txtavg.Name = "txtavg";
            txtavg.Size = new Size(100, 23);
            txtavg.TabIndex = 3;
            // 
            // txtsum
            // 
            txtsum.Location = new Point(92, 26);
            txtsum.Name = "txtsum";
            txtsum.Size = new Size(100, 23);
            txtsum.TabIndex = 2;
            // 
            // avg
            // 
            avg.AutoSize = true;
            avg.Location = new Point(35, 64);
            avg.Name = "avg";
            avg.Size = new Size(31, 15);
            avg.TabIndex = 1;
            avg.Text = "평균";
            // 
            // sum
            // 
            sum.AutoSize = true;
            sum.Location = new Point(35, 29);
            sum.Name = "sum";
            sum.Size = new Size(31, 15);
            sum.TabIndex = 0;
            sum.Text = "총점";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(txtmath);
            groupBox1.Controls.Add(txtko);
            groupBox1.Controls.Add(txteng);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(51, 58);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(256, 215);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "성적입력";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(112, 168);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 5;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // txtmath
            // 
            txtmath.Location = new Point(112, 106);
            txtmath.Name = "txtmath";
            txtmath.Size = new Size(100, 23);
            txtmath.TabIndex = 4;
            txtmath.TextAlign = HorizontalAlignment.Center;
            // 
            // txtko
            // 
            txtko.Location = new Point(112, 47);
            txtko.Name = "txtko";
            txtko.Size = new Size(100, 23);
            txtko.TabIndex = 3;
            txtko.TextAlign = HorizontalAlignment.Center;
            // 
            // txteng
            // 
            txteng.AutoSize = true;
            txteng.Location = new Point(18, 168);
            txteng.Name = "txteng";
            txteng.Size = new Size(31, 15);
            txteng.TabIndex = 2;
            txteng.Text = "영어";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 106);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 1;
            label2.Text = "수학";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 50);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 0;
            label1.Text = "국어";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(685, 375);
            Controls.Add(button1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private GroupBox groupBox2;
        private TextBox txtavg;
        private TextBox txtsum;
        private Label avg;
        private Label sum;
        private GroupBox groupBox1;
        private TextBox textBox3;
        private TextBox txtmath;
        private TextBox txtko;
        private Label txteng;
        private Label label2;
        private Label label1;
    }
}