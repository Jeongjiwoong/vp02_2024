namespace _013_1_convert
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double sum = Convert.ToDouble(txtko.Text)
               + Convert.ToDouble(label2.Text)
               + Convert.ToDouble(txteng.Text);

            double avg = sum / 3;

            txtsum.Text = sum.ToString();
            txtavg.Text = avg.ToString("0.0");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}