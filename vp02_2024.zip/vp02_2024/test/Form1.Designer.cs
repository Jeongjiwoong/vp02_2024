﻿namespace test
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            r5 = new RadioButton();
            r4 = new RadioButton();
            r3 = new RadioButton();
            r2 = new RadioButton();
            r1 = new RadioButton();
            combo1 = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            groupBox2 = new GroupBox();
            c5 = new CheckBox();
            c4 = new CheckBox();
            c3 = new CheckBox();
            c2 = new CheckBox();
            c1 = new CheckBox();
            grade = new TextBox();
            name = new TextBox();
            label5 = new Label();
            button1 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(r5);
            groupBox1.Controls.Add(r4);
            groupBox1.Controls.Add(r3);
            groupBox1.Controls.Add(r2);
            groupBox1.Controls.Add(r1);
            groupBox1.Location = new Point(102, 49);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(264, 155);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // r5
            // 
            r5.AutoSize = true;
            r5.Location = new Point(16, 122);
            r5.Name = "r5";
            r5.Size = new Size(133, 19);
            r5.TabIndex = 4;
            r5.TabStop = true;
            r5.Text = "의료공간디자인학과";
            r5.UseVisualStyleBackColor = true;
            // 
            // r4
            // 
            r4.AutoSize = true;
            r4.Location = new Point(16, 97);
            r4.Name = "r4";
            r4.Size = new Size(109, 19);
            r4.TabIndex = 3;
            r4.TabStop = true;
            r4.Text = "제약생명공학과";
            r4.UseVisualStyleBackColor = true;
            // 
            // r3
            // 
            r3.AutoSize = true;
            r3.Location = new Point(16, 72);
            r3.Name = "r3";
            r3.Size = new Size(121, 19);
            r3.TabIndex = 2;
            r3.TabStop = true;
            r3.Text = "의료신소재공학과";
            r3.UseVisualStyleBackColor = true;
            // 
            // r2
            // 
            r2.AutoSize = true;
            r2.Location = new Point(16, 47);
            r2.Name = "r2";
            r2.Size = new Size(73, 19);
            r2.TabIndex = 1;
            r2.TabStop = true;
            r2.Text = "의공학과";
            r2.UseVisualStyleBackColor = true;
            // 
            // r1
            // 
            r1.AutoSize = true;
            r1.Location = new Point(16, 22);
            r1.Name = "r1";
            r1.Size = new Size(94, 19);
            r1.TabIndex = 0;
            r1.TabStop = true;
            r1.Text = "의료IT공학과";
            r1.UseVisualStyleBackColor = true;
            // 
            // combo1
            // 
            combo1.FormattingEnabled = true;
            combo1.Location = new Point(112, 223);
            combo1.Name = "combo1";
            combo1.Size = new Size(100, 23);
            combo1.TabIndex = 1;
            combo1.SelectedIndexChanged += combo1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(37, 229);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 2;
            label1.Text = "학년";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(37, 271);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 3;
            label2.Text = "학번";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 310);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 4;
            label3.Text = "이름";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(37, 352);
            label4.Name = "label4";
            label4.Size = new Size(31, 45);
            label4.TabIndex = 5;
            label4.Text = "선호\r\n하는\r\n언어";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(c5);
            groupBox2.Controls.Add(c4);
            groupBox2.Controls.Add(c3);
            groupBox2.Controls.Add(c2);
            groupBox2.Controls.Add(c1);
            groupBox2.Location = new Point(104, 342);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(123, 144);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            // 
            // c5
            // 
            c5.AutoSize = true;
            c5.Location = new Point(21, 119);
            c5.Name = "c5";
            c5.Size = new Size(54, 19);
            c5.TabIndex = 4;
            c5.Text = "JAVA";
            c5.UseVisualStyleBackColor = true;
            c5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // c4
            // 
            c4.AutoSize = true;
            c4.Location = new Point(21, 95);
            c4.Name = "c4";
            c4.Size = new Size(41, 19);
            c4.TabIndex = 3;
            c4.Text = "C#";
            c4.UseVisualStyleBackColor = true;
            c4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // c3
            // 
            c3.AutoSize = true;
            c3.Location = new Point(21, 70);
            c3.Name = "c3";
            c3.Size = new Size(50, 19);
            c3.TabIndex = 2;
            c3.Text = "C++";
            c3.UseVisualStyleBackColor = true;
            c3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // c2
            // 
            c2.AutoSize = true;
            c2.Location = new Point(21, 46);
            c2.Name = "c2";
            c2.Size = new Size(34, 19);
            c2.TabIndex = 1;
            c2.Text = "C";
            c2.UseVisualStyleBackColor = true;
            c2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // c1
            // 
            c1.AutoSize = true;
            c1.Location = new Point(21, 21);
            c1.Name = "c1";
            c1.Size = new Size(62, 19);
            c1.TabIndex = 0;
            c1.Text = "파이썬";
            c1.UseVisualStyleBackColor = true;
            c1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // grade
            // 
            grade.Location = new Point(112, 268);
            grade.Name = "grade";
            grade.Size = new Size(100, 23);
            grade.TabIndex = 7;
            // 
            // name
            // 
            name.Location = new Point(112, 313);
            name.Name = "name";
            name.Size = new Size(100, 23);
            name.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(37, 121);
            label5.Name = "label5";
            label5.Size = new Size(31, 15);
            label5.TabIndex = 9;
            label5.Text = "학과";
            // 
            // button1
            // 
            button1.Location = new Point(305, 463);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 10;
            button1.Text = "제출";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(421, 534);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(name);
            Controls.Add(grade);
            Controls.Add(groupBox2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(combo1);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private ComboBox combo1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private GroupBox groupBox2;
        private CheckBox c5;
        private CheckBox c4;
        private CheckBox c3;
        private CheckBox c2;
        private CheckBox c1;
        private RadioButton r2;
        private RadioButton r1;
        private TextBox grade;
        private TextBox name;
        private Label label5;
        private RadioButton r5;
        private RadioButton r4;
        private RadioButton r3;
        private Button button1;
    }
}