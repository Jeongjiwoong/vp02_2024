using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System;
using System.DirectoryServices;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string result = "";
            if (r1.Checked)
                result += "�Ƿ�IT���а�\n";
            else if (r2.Checked)
                result += "�ǰ��а�\n";
            else if (r3.Checked)
                result += "�Ƿ�ż�����а�\n";
            else if (r4.Checked)
                result += "����������а�\n";
            else if (r5.Checked)
                result += "�Ƿ�����������а�\n";
            result += combo1.Text+ "�г�\n";
            result += grade.Text + "\n";
            result += name.Text + "\n";
            CheckBox[] aBox = { c1, c2, c3, c4, c5 };
            foreach(var i in aBox)
            {
                if (i.Checked){
                        result += "��ȣ�ϴ� ���:"+ i.Text+"\n";
                    }
            };
 
            

            MessageBox.Show(result,"�л�����");
        }

        private void combo1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int[] arrcombo = { 1, 2, 3, 4 };
            for (int i = 1; i <= 4; i++)
            {
                combo1.Items.Add(i);
            }
        }
    }
}