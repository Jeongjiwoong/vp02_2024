﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btm = new Button();
            Name = new Label();
            txt = new TextBox();
            SuspendLayout();
            // 
            // btm
            // 
            btm.Location = new Point(275, 93);
            btm.Name = "btm";
            btm.Size = new Size(75, 23);
            btm.TabIndex = 0;
            btm.Text = "출력";
            btm.UseVisualStyleBackColor = true;
            btm.Click += btm_Click;
            // 
            // Name
            // 
            Name.AutoSize = true;
            Name.Location = new Point(63, 96);
            Name.Name = "Name";
            Name.Size = new Size(31, 15);
            Name.TabIndex = 1;
            Name.Text = "이름";
            // 
            // txt
            // 
            txt.Location = new Point(149, 93);
            txt.Name = "txt";
            txt.Size = new Size(100, 23);
            txt.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt);
            Controls.Add(Name);
            Controls.Add(btm);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btm;
        private Label Name;
        private TextBox txt;
    }
}