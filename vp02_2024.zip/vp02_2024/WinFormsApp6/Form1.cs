namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("�̸��� �Է��ϼ���", "Warning");
            else
                label2.Text = textBox1.Text + "��! �ȳ��ϼ���";
        }
    }
}