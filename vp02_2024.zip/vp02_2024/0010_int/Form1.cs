namespace _0010_int
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] arr = { 1, 2, 3, 4, 5 };
            string s = "";

            foreach (int i in arr)
            {
                s += i + " ";
            }
            MessageBox.Show(s, "����");
        }
    }
}