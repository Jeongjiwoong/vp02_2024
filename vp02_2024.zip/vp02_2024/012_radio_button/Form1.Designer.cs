﻿namespace _012_radio_button
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            korea = new RadioButton();
            china = new RadioButton();
            other = new RadioButton();
            japan = new RadioButton();
            label1 = new Label();
            women = new RadioButton();
            men = new RadioButton();
            btm = new Button();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // korea
            // 
            korea.AutoSize = true;
            korea.Location = new Point(17, 22);
            korea.Name = "korea";
            korea.Size = new Size(73, 19);
            korea.TabIndex = 2;
            korea.Text = "대한민국";
            korea.UseVisualStyleBackColor = true;
            korea.CheckedChanged += korea_CheckedChanged;
            // 
            // china
            // 
            china.AutoSize = true;
            china.Location = new Point(17, 47);
            china.Name = "china";
            china.Size = new Size(49, 19);
            china.TabIndex = 3;
            china.Text = "중국";
            china.UseVisualStyleBackColor = true;
            // 
            // other
            // 
            other.AutoSize = true;
            other.Location = new Point(17, 97);
            other.Name = "other";
            other.Size = new Size(81, 19);
            other.TabIndex = 4;
            other.Text = "그 외 국가";
            other.UseVisualStyleBackColor = true;
            // 
            // japan
            // 
            japan.AutoSize = true;
            japan.Location = new Point(17, 72);
            japan.Name = "japan";
            japan.Size = new Size(49, 19);
            japan.TabIndex = 5;
            japan.Text = "일본";
            japan.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(83, 45);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 7;
            // 
            // women
            // 
            women.AutoSize = true;
            women.Location = new Point(137, 44);
            women.Name = "women";
            women.Size = new Size(37, 19);
            women.TabIndex = 10;
            women.Text = "여";
            women.UseVisualStyleBackColor = true;
            // 
            // men
            // 
            men.AutoSize = true;
            men.Location = new Point(20, 44);
            men.Name = "men";
            men.Size = new Size(37, 19);
            men.TabIndex = 11;
            men.Text = "남";
            men.UseVisualStyleBackColor = true;
            // 
            // btm
            // 
            btm.Location = new Point(449, 205);
            btm.Name = "btm";
            btm.Size = new Size(84, 26);
            btm.TabIndex = 12;
            btm.Text = "제출";
            btm.UseVisualStyleBackColor = true;
            btm.Click += btm_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(korea);
            groupBox1.Controls.Add(china);
            groupBox1.Controls.Add(japan);
            groupBox1.Controls.Add(other);
            groupBox1.Location = new Point(62, 63);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(223, 147);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "국적";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(men);
            groupBox2.Controls.Add(women);
            groupBox2.Location = new Point(406, 63);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(200, 100);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "성별";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(btm);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton korea;
        private RadioButton china;
        private RadioButton other;
        private RadioButton japan;
        private Label label1;
        private RadioButton women;
        private RadioButton men;
        private Button btm;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
    }
}