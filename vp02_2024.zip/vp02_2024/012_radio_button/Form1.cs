namespace _012_radio_button
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btm_Click(object sender, EventArgs e)
        {
            string result = "";
            if (korea.Checked)
                result += "���� : ���ѹα�\n";
            else if (china.Checked)
                result += "���� : �߱�\n";
            else if (japan.Checked)
                result += "���� : �Ϻ�\n";
            else if (other.Checked)
                result += "���� : �� �� ����\n";

            if (men.Checked)
                result += "���� : ����";
            else if (women.Checked)
                result += "���� : ����";

            MessageBox.Show(result, "Result");
        }

        private void korea_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}